
import { StyleSheet, Text, View, Pressable, Image } from 'react-native';
import { useState } from 'react';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  const [cliques, atualizarCliques] = useState(0);
  const [cliquess, atualizarCliquess] = useState(0);
  const [cliquesss, atualizarCliquesss] = useState(0);
  const [cliqu, atualizarCliqu] = useState(0);

  const [bfsta, bfpos] = useState(
    require('./assets/Boyfriend.gif')
  );

  return (
    <View style={styles.container}>
      <View>
        <View>
          <Text style={styles.paragraph}>
            Tuesday Morning Coding
          </Text>

          <Text style={styles.paragraph}>
            Contador
          </Text>

          <View style={styles.contadores}>
            <Text style={styles.paragraph}>{cliques}</Text>
            <Text style={styles.paragraph}>{cliquess}</Text>
            <Text style={styles.paragraph}>{cliquesss}</Text>
            <Text style={styles.paragraph}>{cliqu}</Text>
          </View>
        </View>

        <Text style={styles.paragraph}>Acertar</Text>

        <View style={styles.fnfbuttons}>
          <View style={styles.butao}>
            <Pressable
              onPress={() => {
                atualizarCliques(cliques + 1);
                bfpos(require('./assets/BoyfriendLeft.gif'));

                if (
                  cliques + 1 >= 10 &&
                  cliquess + 1 >= 10 &&
                  cliquesss + 1 >= 10 &&
                  cliqu + 1 >= 10
                ) {
                  alert(
                    "Parabéns! Você clicou em cada seta 10 vezes! Por favor feche o React Native e jogue um jogo de verdade."
                  );
                }
              }}
            >
              <Image
                source={require('./assets/left.png')}
                style={styles.icons}
              />
            </Pressable>
          </View>

          <View style={styles.butao}>
            <Pressable
              onPress={() => {
                atualizarCliquess(cliquess + 1);
                bfpos(require('./assets/BoyfriendDown.gif'));

                if (
                  cliques + 1 >= 10 &&
                  cliquess + 1 >= 10 &&
                  cliquesss + 1 >= 10 &&
                  cliqu + 1 >= 10
                ) {
                  alert(
                    "Parabéns! Você clicou em cada seta 10 vezes! Por favor feche o React Native e jogue um jogo de verdade."
                  );
                }
              }}
            >
              <Image
                source={require('./assets/down.png')}
                style={styles.icons}
              />
            </Pressable>
          </View>

          <View style={styles.butao}>
            <Pressable
              onPress={() => {
                atualizarCliquesss(cliquesss + 1);
                bfpos(require('./assets/BoyfriendUp.gif'));

                if (
                  cliques + 1 >= 10 &&
                  cliquess + 1 >= 10 &&
                  cliquesss + 1 >= 10 &&
                  cliqu + 1 >= 10
                ) {
                  alert(
                    "Parabéns! Você clicou em cada seta 10 vezes! Por favor feche o React Native e jogue um jogo de verdade."
                  );
                }
              }}
            >
              <Image
                source={require('./assets/up.png')}
                style={styles.icons}
              />
            </Pressable>
          </View>

          <View style={styles.butao}>
            <Pressable
              onPress={() => {
                atualizarCliqu(cliqu + 1);
                bfpos(require('./assets/BoyfriendRight.gif'));

                if (
                  cliques + 1 >= 10 &&
                  cliquess + 1 >= 10 &&
                  cliquesss + 1 >= 10 &&
                  cliqu + 1 >= 10
                ) {
                  alert(
                    "Parabéns! Você clicou em cada seta 10 vezes! Por favor feche o React Native e jogue um jogo de verdade."
                  );
                }
              }}
            >
              <Image
                source={require('./assets/right.png')}
                style={styles.icons}
              />
            </Pressable>
          </View>
        </View>

        <Text style={styles.paragraph}>Errar</Text>

        <View style={styles.fnfbuttons}>
          <View style={styles.butao}>
            <Pressable
              onPress={() => {
                atualizarCliques(Math.max(0, cliques - 1));
                bfpos(require('./assets/BoyfriendLeftMiss.gif'));
              }}
            >
              <Image
                source={require('./assets/left.png')}
                style={styles.iconsm}
              />
            </Pressable>
          </View>

          <View style={styles.butao}>
            <Pressable
              onPress={() => {
                atualizarCliquess(Math.max(0, cliquess - 1));
                bfpos(require('./assets/BoyfriendDownMiss.gif'));
              }}
            >
              <Image
                source={require('./assets/down.png')}
                style={styles.iconsm}
              />
            </Pressable>
          </View>

          <View style={styles.butao}>
            <Pressable
              onPress={() => {
                atualizarCliquesss(Math.max(0, cliquesss - 1));
                bfpos(require('./assets/BoyfriendUpMiss.gif'));
              }}
            >
              <Image
                source={require('./assets/up.png')}
                style={styles.iconsm}
              />
            </Pressable>
          </View>

          <View style={styles.butao}>
            <Pressable
              onPress={() => {
                atualizarCliqu(Math.max(0, cliqu - 1));
                bfpos(require('./assets/BoyfriendRightMiss.gif'));
              }}
            >
              <Image
                source={require('./assets/right.png')}
                style={styles.iconsm}
              />
            </Pressable>
          </View>
        </View>

        <View style={styles.iconsd}>
          <Pressable
            onPress={() => {
              bfpos(require('./assets/Boyfriend.gif'));

              atualizarCliques(cliques - cliques);
              atualizarCliquess(cliques - cliques);
              atualizarCliquesss(cliquess - cliquess);
              atualizarCliqu(cliqu - cliqu);
            }}
          >
            <Text>
              <strong>Zerar</strong>
            </Text>
          </Pressable>
        </View>

        <View>
          <Pressable
            onPress={() => {
              bfpos(require('./assets/BF_PEACE_ANIMATED.gif'));
            }}
          >
            <Image
              source={bfsta}
              style={styles.boyfriend}
            />
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  paragraph: {
    margin: 2,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginLeft: '28px',
    marginRight: '28px',
  },

  butao: {
    justifyContent: 'center',
    alignSelf: 'center',
    margin: '2px',
    border: '8px, solid, #e0e0e0',
    borderRadius: '12px',
  },

  fnfbuttons: {
    flex: 1,
    flexDirection: 'row',
    alignSelf: 'center',
    backgroundColor: 'white',
  },

  contadores: {
    flex: 1,
    flexDirection: 'row',
    alignSelf: 'center',
  },

  icons: {
    height: '8vh',
    width: '8vh',
  },

  iconsd: {
    height: '8vh',
    width: '8vh',
    alignSelf: 'center',
    backgroundColor: '#ffff45',
    alignItems: 'center',
    justifyContent: 'center',
    border: '4px solid #ad7c00',
    margin: '2px',
  },

  iconsm: {
    height: '8vh',
    width: '8vh',
    filter: 'grayscale(100%)',
  },

  boyfriend: {
    height: '200px',
    width: '200px',
    alignSelf: 'center',
    marginTop: '10px',
  },
});